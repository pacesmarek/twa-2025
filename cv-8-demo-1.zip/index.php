<?php
	// Start a new session or resume the existing session
	session_start();

	// Define the path to the tickets JSON file
	$dataFile = __DIR__ . '/src/tickets.json';

	// Read existing tickets from the JSON file (if it exists), otherwise initialize an empty array
	$tickets = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];

	// Ensure $tickets is always an array to avoid errors
	if (!is_array($tickets)){
		$tickets = [];

	}

	// Handle AJAX Requests sent via POST method
	if ($_SERVER['REQUEST_METHOD'] === 'POST'){

		// Check if the user is logged in (Simple authentication check)
		if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']){
			http_response_code(403);

			// Return "403 Forbidden" if the user is not logged in
			echo json_encode(["error" => "Unauthorized"]);
			exit;
			// Stop further execution
		}

		// Get the requested action from the POST request
		$action = isset($_POST['action']) ? $_POST['action'] : '';

		// Handle adding a new ticket
		if ($action === 'add'){
			// Create a new ticket array
			$newTicket = [
				'id' => time(), // Use current timestamp as a unique ID
				'title' => $_POST['title'] ?? 'Untitled', // Get title from form, default to 'Untitled'
				'description' => $_POST['description'] ?? '' // Get description, default to empty
			];
			$tickets[] = $newTicket;
			// Add the new ticket to the array
		} elseif ($action === 'delete'){
			// Handle deleting a ticket
			$ticketId = intval($_POST['id']);
			// Get the ticket ID from the request

			// Filter the tickets array and remove the ticket with the matching ID
			$tickets = array_filter($tickets, function ($ticket) use ($ticketId){
				return $ticket['id'] !== $ticketId;
			});

			// Re-index the array after deletion
			$tickets = array_values($tickets);
		}

		// Save the updated ticket list back to the JSON file
		file_put_contents($dataFile, json_encode($tickets, JSON_PRETTY_PRINT));

		// Set the response type to JSON and return the updated tickets list
		header('Content-Type: application/json');
		echo json_encode($tickets);
		exit;
		// Stop further execution
	}

?>



<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="dist/style.css">
	<title>Homepage</title>
</head>

<body>
	<div class="container" x-data="ticketApp">
		<div class="row justify-content-center">
			<div class="col-md-4">
				<?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] ): ?>
					<p>Welcome, Admin! <a href="login.php?logout=true">Logout</a></p>
				<?php else: ?>
					<a href="login.php">Login</a> to manage tickets.
				<?php endif; ?>

				<!-- Add Ticket Form -->
				<?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
					<form @submit.prevent="addTicket" class="addTicketForm">
						<div>
							<div>
								<label for="title">Title</label>
								<input type="text" id="title" x-model="newTitle" required>
							</div>
							<div>
								<label for="description">Description</label>
								<textarea id="description" x-model="newDescription" required></textarea>
							</div>
						</div>
						<button type="submit">Add Ticket</button>
					</form>
				<?php endif; ?>

				<!-- Ticket List -->
				<ul class="tickets">
					<template x-for="ticket in tickets" :key="ticket.id">
						<li class="tickets__item">
							<div>
								<strong x-text="ticket.title"></strong>
								<p x-text="ticket.description"></p>
							</div>
							<?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
								<button @click="removeTicket(ticket.id)">Delete</button>
							<?php endif; ?>
						</li>
					</template>
				</ul>
			</div>
		</div>
	</div>
</div>

<script type="module" src="dist/main.js"></script>
</body>
</html>
