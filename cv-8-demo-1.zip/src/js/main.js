// Import Alpine.js, a minimal JavaScript framework for declarative UI handling
import Alpine from "alpinejs";

// Attach Alpine.js to the `window` object to make it globally accessible
window.Alpine = Alpine;

// Listen for the Alpine.js initialization event
document.addEventListener("alpine:init", () => {
	// Define a new Alpine.js data component called "ticketApp"
	Alpine.data("ticketApp", () => ({
		tickets: [], // Array to store ticket data
		newTitle: "", // Stores the new ticket title from the input field
		newDescription: "", // Stores the new ticket description from the input field
		errorMessage: "", // Stores error messages for UI feedback

		/**
		 * Lifecycle hook: Runs when the component is initialized
		 */
		init() {
			this.loadTickets(); // Load existing tickets from JSON file
		},

		/**
		 * Fetches ticket data from `tickets.json` and updates the `tickets` array
		 */
		loadTickets() {
			fetch("/src/tickets.json") // Fetch ticket data from a local JSON file
				.then((response) => response.json()) // Convert response to JSON
				.then((data) => (this.tickets = data)); // Store ticket data in component state
		},

		/**
		 * Sends a request to add a new ticket
		 * The request is sent to `index.php` using the POST method
		 */
		addTicket() {
			fetch("/index.php", {
				method: "POST", // Send data as a POST request
				headers: { "Content-Type": "application/x-www-form-urlencoded" },
				body: new URLSearchParams({
					action: "add", // Specifies the server action
					title: this.newTitle, // Sends the ticket title
					description: this.newDescription, // Sends the ticket description
				}),
			})
			.then((response) => {
				if (response.status === 403) {
					// Check if user is unauthorized
					this.errorMessage = "You must be logged in to add tickets."; // Show error message
					return;
				}
				return response.json(); // Convert response to JSON
			})
			.then((data) => {
				if (data) {
					this.tickets = data; // Update ticket list with new data
					this.newTitle = ""; // Clear input fields after successful addition
					this.newDescription = "";
				}
			});
		},

		/**
		 * Sends a request to delete a ticket by ID
		 * The request is sent to `index.php` with the `delete` action
		 */
		removeTicket(id) {
			fetch("/index.php", {
				method: "POST", // Send a POST request
				headers: { "Content-Type": "application/x-www-form-urlencoded" },
				body: new URLSearchParams({
					action: "delete", // Specifies the delete action
					id: id, // Sends the ticket ID to be deleted
				}),
			})
			.then((response) => response.json()) // Convert response to JSON
			.then((data) => (this.tickets = data)); // Update ticket list after deletion
		},
	}));
});

// Start Alpine.js to initialize components
Alpine.start();
